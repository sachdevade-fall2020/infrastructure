exports.handler = function(event, context) {
    console.log("Hello World!");
    console.log(event);
}